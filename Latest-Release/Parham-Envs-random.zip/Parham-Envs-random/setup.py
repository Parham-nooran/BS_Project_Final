from setuptools import setup

setup(
    name='parham_envs',
    version='0.0.1',
    install_rquires=['pybullet', 'gym', 'numpy', 'matplotlib']
)