from setuptools import setup

setup(
    name='rex_gym',
    version='0.9.1',
    install_rquires=['pybullet', 'gym', 'numpy', 'matplotlib']
)