from setuptools import setup

setup(
    name='ant_bullet_env',
    version='0.3.0',
    install_rquires=['pybullet', 'gym', 'numpy', 'matplotlib']
)